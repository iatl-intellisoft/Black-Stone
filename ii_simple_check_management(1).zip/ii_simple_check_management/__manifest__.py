# -*- coding: utf-8 -*-
{
    'name': "Simple Check Management",

    'summary': """
        Simple Check Management""",

    'description': """
        Simple Check Management
    """,
    'author': "Iatl-intellisoft",
    'category': 'Accounting',
    'version': '0.1',
    'depends': ['account'],
    'data': [
        #'views/payment.xml',
    ],
}
